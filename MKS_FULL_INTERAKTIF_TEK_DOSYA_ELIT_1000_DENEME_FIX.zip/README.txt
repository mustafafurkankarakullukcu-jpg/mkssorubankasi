Deneme Bölümü doğrudan 1000 soru gösterir. Elit Denemeler ayrıca 500 soru olarak ayrı bölümde de görünür.

FINAL: Ana ekranda DENEME BÖLÜMÜ - 1000 SORU olarak görünür. Elit Denemeler ayrıca 500 soru görünür. Netlify/GitHub cache karışmasın diye yeni paket adı kullanıldı.

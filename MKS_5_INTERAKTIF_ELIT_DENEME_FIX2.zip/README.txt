FIX2: Butonlara type=button eklendi ve tıklama/indirme çakışmasına karşı koruma kondu.
